package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Practical05Activity extends AppCompatActivity {

    private TextView log;
    private final StringBuilder buffer = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical05);
        log = findViewById(R.id.lifecycle_log);
        append("onCreate\n");
    }

    @Override
    protected void onStart() {
        super.onStart();
        append("onStart\n");
    }

    @Override
    protected void onResume() {
        super.onResume();
        append("onResume\n");
    }

    @Override
    protected void onPause() {
        append("onPause\n");
        super.onPause();
    }

    @Override
    protected void onStop() {
        append("onStop\n");
        super.onStop();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        append("onRestart\n");
    }

    @Override
    protected void onDestroy() {
        append("onDestroy\n");
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        append("onSaveInstanceState\n");
        super.onSaveInstanceState(outState);
    }

    private void append(String line) {
        buffer.append(line);
        log.setText(buffer.toString());
        String name = line.trim();
        if (!name.isEmpty()) {
            Toast.makeText(this, name, Toast.LENGTH_SHORT).show();
        }
    }
}
