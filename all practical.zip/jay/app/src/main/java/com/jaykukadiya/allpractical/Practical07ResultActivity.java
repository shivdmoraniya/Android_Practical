package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical07ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical07_result);
        String u = getIntent().getStringExtra("u");
        String p = getIntent().getStringExtra("p");
        TextView outUser = findViewById(R.id.out_user);
        TextView outPass = findViewById(R.id.out_pass);
        outUser.setText("Username: " + u);
        outPass.setText("Password: " + p);
    }
}
