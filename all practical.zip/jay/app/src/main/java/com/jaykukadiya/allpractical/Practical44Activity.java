package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Practical44Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical44);
        Button show = findViewById(R.id.show);
        show.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Demo")
                .setMessage("This is an AlertDialog.")
                .setPositiveButton("OK", (d, w) -> d.dismiss())
                .setNegativeButton("Cancel", (d, w) -> d.dismiss())
                .show());
    }
}
