package com.jaykukadiya.allpractical;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical06Activity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "username";
    private static final String USER = "jay";
    private static final String PASS = "jay";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical06);
        EditText user = findViewById(R.id.username);
        EditText pass = findViewById(R.id.password);
        Button login = findViewById(R.id.login);
        login.setOnClickListener(v -> {
            String u = user.getText().toString().trim();
            String p = pass.getText().toString();
            if (USER.equals(u) && PASS.equals(p)) {
                Intent i = new Intent(this, Practical06WelcomeActivity.class);
                i.putExtra(EXTRA_USERNAME, u);
                startActivity(i);
            } else {
                Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
